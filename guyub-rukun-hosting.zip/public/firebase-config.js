// Isi dengan data dari Firebase Console (lihat PANDUAN.md, Bagian A langkah 4).
// Selama masih "ISI_...", aplikasi berjalan tanpa penyimpanan online (hanya contoh).
export const firebaseConfig = {
  apiKey: "ISI_API_KEY",
  authDomain: "ISI_PROJECT_ID.firebaseapp.com",
  projectId: "ISI_PROJECT_ID",
  appId: "ISI_APP_ID"
};
