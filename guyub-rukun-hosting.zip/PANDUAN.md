# Panduan Pasang Aplikasi Guyub Rukun 05.08 di Hosting Sendiri

Setelah ini warga cukup membuka **satu link biasa** tanpa akun Claude, lalu memasangnya di HP (Android dan iPhone) dengan ikon logo Guyub Rukun.

## Isi paket

| Berkas | Fungsi |
|---|---|
| `public/` | Seluruh aplikasi. Folder inilah yang diunggah ke hosting |
| `public/firebase-config.js` | **Wajib Anda isi** dengan data dari Firebase |
| `firestore.rules` | Aturan keamanan: hanya 5 pengurus yang bisa mengedit. **Wajib ganti 5 email** |
| `firebase.json`, `netlify.toml`, `vercel.json` | Pengaturan hosting, tidak perlu diubah |

## Cara kerjanya

- **Firebase** menyimpan data (database) dan login 5 pengurus. Ini wajib, apa pun hosting yang Anda pilih.
- **Netlify, Vercel, atau Firebase Hosting** hanya menayangkan tampilan aplikasi. Pilih salah satu saja.
- Pengurus: login email dan kata sandi, bisa mengedit semua data.
- Warga: tanpa login, bisa melihat semua data, dan bisa mengisi **absen ronda dan jimpitan**.

---

## BAGIAN A. Siapkan Firebase (wajib, sekitar 15 menit)

Siapkan akun Google. Paket gratis (Spark) biasanya cukup untuk 90 KK. Cek batas terbaru di situs Firebase.

1. Buka https://console.firebase.google.com, klik **Create a project** (Tambah project), beri nama misalnya `guyub-rukun-0508`. Google Analytics boleh dimatikan.
2. Menu **Build, lalu Firestore Database, lalu Create database**. Pilih **Production mode**. Untuk lokasi pilih yang terdekat, misalnya Jakarta (`asia-southeast2`) jika tersedia. Lokasi tidak bisa diganti nanti.
3. Menu **Build, lalu Authentication, lalu Get started**. Di tab **Sign-in method** aktifkan **Email/Password**. Lalu buka tab **Users** dan klik **Add user** sebanyak 5 kali (email dan kata sandi masing-masing pengurus). Catat kata sandinya dan serahkan ke pengurus yang bersangkutan.
4. Klik ikon roda gigi lalu **Project settings**. Di bagian **Your apps** klik ikon web `</>`, beri nama aplikasi, lalu **Register app**. Akan muncul kode berisi `firebaseConfig`. Salin nilai `apiKey`, `authDomain`, `projectId`, dan `appId` ke berkas **`public/firebase-config.js`**, menggantikan tulisan `ISI_...`.
5. Buka berkas **`firestore.rules`** dan ganti kelima `pengurusN@contoh.com` dengan email 5 pengurus tadi (harus sama persis dengan yang dibuat di langkah 3). Di Firebase buka **Firestore Database, lalu Rules**, hapus isinya, tempel seluruh isi `firestore.rules`, lalu klik **Publish**.

> Penting: lakukan langkah 3 (membuat kelima akun) **sebelum** aplikasi dibagikan ke warga.

---

## BAGIAN B. Pilih satu hosting

### Pilihan 1. Netlify (paling mudah, tanpa instal apa pun)

1. Buka https://app.netlify.com dan daftar (bisa dengan akun Google).
2. Klik **Add new site, lalu Deploy manually**.
3. **Tarik folder `public`** (bukan seluruh paket) ke kotak unggah.
4. Tunggu beberapa detik. Anda mendapat alamat seperti `nama-acak.netlify.app`. Ganti nama di **Site configuration, lalu Change site name**, misalnya `guyub-rukun-0508`.
5. Untuk memperbarui aplikasi kelak: buka tab **Deploys** dan tarik lagi folder `public`.

### Pilihan 2. Vercel

Vercel tidak punya unggah tarik-lepas. Ada dua jalan:

**Lewat komputer (CLI):**
1. Pasang Node.js (https://nodejs.org), lalu jalankan di terminal: `npm i -g vercel`
2. Masuk ke folder paket ini (yang berisi `vercel.json`), lalu jalankan `vercel` dan ikuti pertanyaannya. Pilih framework **Other**. Folder keluaran sudah diatur ke `public`.
3. Jalankan `vercel --prod` untuk mendapatkan alamat final `nama.vercel.app`.

**Lewat GitHub:** unggah paket ke repositori GitHub, lalu di https://vercel.com klik **Add New, lalu Project**, pilih repositori itu. Kalau diminta, isi **Output Directory** dengan `public` dan kosongkan Build Command.

### Pilihan 3. Firebase Hosting (satu tempat dengan database)

1. Pasang Node.js, lalu di terminal: `npm i -g firebase-tools` dan `firebase login`
2. Masuk ke folder paket ini, lalu jalankan `firebase use --add`. Pilih project Firebase tadi dan beri alias `default`.
3. Jalankan `firebase deploy`. Perintah ini mengunggah aplikasi sekaligus aturan keamanan.
4. Alamatnya berbentuk `nama-project.web.app`.

---

## BAGIAN C. Setelah terpasang

1. Jika **login pengurus gagal** di alamat baru, buka Firebase: **Authentication, lalu Settings, lalu Authorized domains**, lalu tambahkan alamat hosting Anda (misalnya `guyub-rukun-0508.netlify.app`).
2. **Uji dulu sebelum dibagikan:**
   - Buka link di HP, ketuk **Mode Warga · Masuk Pengurus**, masuk dengan salah satu akun pengurus.
   - Ubah sesuatu, misalnya isi nama satu warga, lalu buka link di HP lain. Datanya harus ikut berubah.
   - Isi absen ronda tanpa login di HP lain. Harus berhasil.
   - Masuk dengan akun yang **bukan** dari 5 email di aturan. Menyimpan harus ditolak.
3. **Pasang di HP:**
   - **iPhone:** buka link di **Safari**, ketuk **Bagikan**, lalu **Tambah ke Layar Utama**.
   - **Android:** buka di **Chrome**, ketuk menu ⋮, lalu **Pasang aplikasi** atau **Tambahkan ke layar utama**. Di Beranda aplikasi juga ada tombol Pasang aplikasi.
4. Bagikan link ke grup WhatsApp warga.

---

## Hal yang perlu diketahui

- **Data dapat dibaca siapa pun yang punya link**, termasuk nama dan nomor HP warga. Bagikan link hanya di grup RT. Jika tidak ingin nomor HP tersimpan, jangan isi kolom HP.
- **Absen ronda dan jimpitan dapat diisi siapa pun yang punya link**, tanpa login. Bentuk datanya dibatasi aturan, tapi tidak ada pengaman terhadap orang yang sengaja mengisi sembarangan. Jika disalahgunakan, pengurus bisa memperbaiki angkanya, dan jalan keluarnya adalah menambahkan login untuk warga.
- Jika dua pengurus mengubah bagian yang sama di detik yang sama, yang menyimpan terakhir yang dipakai. Sebaiknya jangan mengedit bagian yang sama bersamaan.
- Jimpitan dihitung terpisah dari Kas RT. Denda ronda diisi manual oleh pengurus.
- Tidak ada fitur cadangan otomatis. Data bisa dilihat di Firebase Console, bagian Firestore Database. Cek di sana juga cara ekspor data.

## Masalah umum

| Masalah | Cara mengatasi |
|---|---|
| Tulisan "Firebase belum diatur" | `public/firebase-config.js` masih berisi `ISI_...`. Isi, lalu unggah ulang |
| "Email atau kata sandi salah" | Cek akun di Authentication, tab Users. Kata sandi bisa di-reset di sana |
| "Akun ini tidak diizinkan mengedit" | Email akun belum ada di `firestore.rules`, atau aturan belum di-Publish |
| "Gagal memuat data" | Firestore belum dibuat, atau aturan membatasi akses. Cek Bagian A langkah 2 dan 5 |
| Perubahan aplikasi tidak muncul di HP | Tutup aplikasi sepenuhnya lalu buka lagi. Jika masih lama, hapus pintasan lalu pasang ulang |
| Cetak surat tidak muncul di HP | Pakai tombol **Unduh**, lalu cetak dari Word atau WPS |
